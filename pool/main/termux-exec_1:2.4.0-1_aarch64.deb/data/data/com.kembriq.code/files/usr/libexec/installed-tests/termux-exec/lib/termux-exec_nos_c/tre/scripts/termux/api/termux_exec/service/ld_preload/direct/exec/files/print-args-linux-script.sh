#!/data/data/com.kembriq.code/files/usr/bin/sh

echo "$@"
