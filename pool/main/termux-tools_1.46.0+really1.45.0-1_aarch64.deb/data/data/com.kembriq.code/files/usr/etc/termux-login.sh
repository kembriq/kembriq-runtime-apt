##
## This script is sourced by /data/data/com.kembriq.code/files/usr/bin/login before executing shell.
##
