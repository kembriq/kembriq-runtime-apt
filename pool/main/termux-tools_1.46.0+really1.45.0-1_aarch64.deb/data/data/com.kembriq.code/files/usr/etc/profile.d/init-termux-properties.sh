if [ ! -f /data/data/com.kembriq.code/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.kembriq.code/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.kembriq.code/files/home/.termux
	cp /data/data/com.kembriq.code/files/usr/share/examples/termux/termux.properties /data/data/com.kembriq.code/files/home/.termux/
fi
